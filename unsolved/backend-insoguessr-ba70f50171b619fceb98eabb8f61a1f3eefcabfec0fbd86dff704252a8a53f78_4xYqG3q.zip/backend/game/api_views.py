import json
import hashlib
import base64
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login
from django.utils.decorators import method_decorator
from django.conf import settings
from .models import Player
from django.contrib.auth.models import User

SECRET_KEY = settings.SIGNATURE_KEY

# Base API, middleware, signature checker
@method_decorator(csrf_exempt, name='dispatch')
class BaseApiView(View):
    def dispatch(self, request, *args, **kwargs):
        """Verify signature before processing the request."""
        if not self.verify_signature(request):
            return JsonResponse({'error': 'Invalid signature'}, status=403)

        return super().dispatch(request, *args, **kwargs)

    def verify_signature(self, request):
        pass
        ## REDACTED ;)


# Login endpoint
class LoginApiView(BaseApiView):
    def post(self, request, *args, **kwargs):
        """Handle /api/login endpoint."""
        try:
            data = json.loads(request.body.decode('utf-8'))
            username = data.get('username')
            password = data.get('password')

            user = authenticate(username=username, password=password)
            
            if user is not None:
                login(request,user)
                
                player, created = Player.objects.get_or_create(user=request.user)
                if created:
                    player.save()

                player.achievements_mobile_user = True;
                player.save()

                # Retrieve session
                session_token = request.session.session_key

                # If first login
                if not session_token:
                    request.session.create()
                    session_token = request.session.session_key

                return JsonResponse({'status': 'success', 'message': 'Login successful', 'token': session_token})
            else:
                return JsonResponse({'status': 'error', 'message': 'Invalid credentials'}, status=401)
        except (json.JSONDecodeError, KeyError):
            return JsonResponse({'error': 'Invalid request format'}, status=400)


# Status endpoint
class StatusApiView(BaseApiView):
    def post(self, request, *args, **kwargs):

        if request.user.is_authenticated:
            
            user_data = {
                'isLogged': True,
                'uid': request.user.id,
            }
            return JsonResponse({
                'status': 'success',
                'message': 'User status retrieved successfully',
                'data': user_data
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': 'User is not authenticated'
            }, status=401)


# Profile endpoint
class ProfileApiView(BaseApiView):
    def post(self, request, *args, **kwargs):
        """Handle /api/profile endpoint.""" 
        if request.user.is_authenticated:

            try:
                data = json.loads(request.body.decode('utf-8'))
                uid = data.get('uid')
                showAchievement = data.get('showAchievements')

                player = Player.objects.get(user_id=uid)

                user_data = {
                    'uid': None,
                    'best_leaderboard' : None,
                    'nbr_games' : None,
                    'nbr_wins' : None,
                    'username' : None,
                    'best_score' : None,
                    'best_guess': None,
                    'achievements':{
                        'mobile_user': None,
                        'mobile_expert': None,
                    }
                }

                user_data['best_leaderboard'] = player.best_leaderboard
                user_data['nbr_games'] = player.nbr_games
                user_data['username'] = request.user.username
                user_data['nbr_wins'] = player.nbr_wins
                user_data['best_score'] = player.best_score
                user_data['best_guess'] = player.best_guess
                user_data['uid'] = uid

                #if showAchievements == True returns also the achievements.
                if(showAchievement == True):
                    
                    user_data['achievements']['mobile_user'] = player.achievements_mobile_user
                    user_data['achievements']['mobile_expert'] = player.achievements_mobile_expert
                    
                    return JsonResponse({
                        'status': 'success',
                        'message': 'User profile retrieved successfully',
                        'data': user_data 
                        }, status=200)
                else:
                    return JsonResponse({
                        'status': 'success',
                        'message': 'User profile retrieved successfully',
                        'data': user_data 
                        }, status=200)


            except (json.JSONDecodeError, KeyError):
                return JsonResponse({'error': 'Invalid request format'}, status=400)

        else:
            return JsonResponse({
                'status': 'error',
                'message': 'User is not authenticated'
            }, status=401)
