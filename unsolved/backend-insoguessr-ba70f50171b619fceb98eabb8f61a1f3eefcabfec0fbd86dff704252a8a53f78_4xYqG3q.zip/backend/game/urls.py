from django.urls import path
from . import views
from game.api_views import LoginApiView, StatusApiView, ProfileApiView


urlpatterns = [
    path('', views.index, name='index'),
    ## Mobile API for mobile chall
    path('api/status', StatusApiView.as_view(), name='api_status'),
    path('api/login', LoginApiView.as_view(), name='api_login'),
    path('api/profile', ProfileApiView.as_view(), name='api_profile'),
    ## Web part
    path('profile/', views.profile_view, name='profile'),
    path('ranking/', views.ranking_view, name='ranking'),
    path('game/', views.game, name='game'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('submit_guess/', views.submit_guess, name='submit_guess'),
    path('party_result/', views.party_result, name='party_result'),
    path('lobby/reset/', views.lobby_reset, name='lobby_reset'),
    path('api/game-data/', views.game_data_api, name='game_data_api'),
    path('api/result-data/', views.result_data_api, name='result_data_api'), 
]
