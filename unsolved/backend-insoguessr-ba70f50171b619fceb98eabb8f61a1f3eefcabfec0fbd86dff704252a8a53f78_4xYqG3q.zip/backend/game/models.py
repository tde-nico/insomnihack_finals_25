from django.db import models
from django.contrib.auth.models import User

class Location(models.Model):
    latitude = models.FloatField()
    longitude = models.FloatField()
    compass = models.FloatField(default = 0.0)
    image_url = models.URLField()

class Game(models.Model):
    game_id = models.TextField(null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    score = models.IntegerField(default=0)
    guessed_latitude = models.FloatField(default=0.0)
    guessed_longitude = models.FloatField(default=0.0)
    distance = models.FloatField()
    game_step = models.IntegerField(default=0)
    room = models.IntegerField()
    date_played = models.DateTimeField(auto_now_add=True)

class Result(models.Model):
    game_id = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    room = models.IntegerField()
    score = models.IntegerField(default=0)
    leaderboard = models.IntegerField()
    date_played = models.DateTimeField(auto_now_add=True)

class Player(models.Model):
    user = models.ForeignKey(User, primary_key=True, on_delete=models.CASCADE)
    current_game_id = models.TextField(null=True)
    current_game_step = models.IntegerField(default=0)
    best_guess = models.IntegerField(default=0)
    best_score = models.IntegerField(default=0)
    best_leaderboard = models.IntegerField(null=True)
    nbr_games = models.IntegerField(default=0)
    nbr_wins = models.IntegerField(default=0)
    achievements_one_win = models.BooleanField(default=False)
    achievements_perfect_score = models.BooleanField(default=False)
    achievements_how_did_we_get_here = models.BooleanField(default=False)
    achievements_mobile_user = models.BooleanField(default=False)
    achievements_mobile_expert = models.TextField(null=True)

class Lobby(models.Model):
    players = models.ManyToManyField(User, related_name="lobby_players", blank=True)
    started = models.BooleanField(default=False)
    current_game_id = models.TextField(null=True)
    location_id = models.IntegerField(null=True)
    current_step = models.IntegerField(default=0)
    round_start_time = models.DateTimeField(null=True)
    sleep_time = models.IntegerField(null=True)

    @classmethod
    def get_lobby(cls):
        lobby, created = cls.objects.get_or_create(id=1)
        return lobby
