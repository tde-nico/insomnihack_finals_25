from django.urls import re_path
from .consumers import RealLobbyConsumer
from channels.auth import AuthMiddlewareStack

websocket_urlpatterns = [
    re_path(r'ws/real-lobby/$', RealLobbyConsumer.as_asgi()),
]
