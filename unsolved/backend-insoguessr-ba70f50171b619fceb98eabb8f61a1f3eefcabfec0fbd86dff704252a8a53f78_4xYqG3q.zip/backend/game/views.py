from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.db.models import Min, Max
from django.db.models import Avg, Sum, Count, Case, When, F, Func, Value, IntegerField, FloatField, CharField
from django.db.models.functions import Round, Concat, Coalesce
from django.contrib import messages
from django.conf import settings
from django.http import JsonResponse
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from .models import Location, Game, Lobby, Result, Player
import random
import asyncio
import math
import uuid


def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, "Account created successfully!")
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form, 'shownavbar': True})


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.warning(request, "Invalid username or password")
    return render(request, 'registration/login.html', {'shownavbar': True})


def logout_view(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect('login')


@login_required
def index(request):
    return render(request, 'game/panel.html', {'shownavbar': True})

@login_required
def game(request):
    return render(request, 'game/main.html', {
        'websocket_url': 'wss://insoguessr.insomnihack.ch/ws/real-lobby/',
        #'tile_server_url': 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'tile_server_url': 'https://insoguessr-tiles.insomnihack.ch/tile/{z}/{x}/{y}.png',
        'max_zoom': 11,
        })

@login_required
def game_data_api(request):
    location_id = Lobby.get_lobby().location_id
    location = get_object_or_404(Location, id=location_id)
    location_json = {
        'compass': location.compass,
        'image_url': location.image_url,
        'id': location.id,
    }
    return JsonResponse({'location': location_json})

@login_required
def result_data_api(request):
    lobby = Lobby.get_lobby()
    location_id = lobby.location_id
    game_step = int(lobby.current_step/2)
    game_id = lobby.current_game_id
    location = get_object_or_404(Location, id=location_id)
    guess = Game.objects.filter(game_id=game_id, game_step=game_step, user=request.user).first()

    # ingame
    if lobby.current_step % 2 == 0:
        return HttpResponse('ko', status=401)

    if guess:
        return JsonResponse({
            'score': guess.score,
            'distance': guess.distance,
            'actual_lat': location.latitude,
            'actual_lng': location.longitude,
            'game_step': game_step
        })

    else:
        return JsonResponse({
        'score': 0,
        'distance': None,
        'actual_lat': location.latitude,
        'actual_lng': location.longitude,
        'game_step': game_step
        })


def compute_user_data(user):
    player, created = Player.objects.get_or_create(user=user)
    if created:
        player.save()

    user_data = {
        'user_id': user.id % 10,
        'best_leaderboard' : None,
        'nbr_games' : None,
        'nbr_wins' : None,
        'best_score' : None,
        'best_guess': None,
        'achievements':{
            'one_win': None,
            'perfect_score': None,
        }
    }

    user_data['best_leaderboard'] = player.best_leaderboard
    user_data['nbr_games'] = player.nbr_games
    user_data['nbr_wins'] = player.nbr_wins
    user_data['best_score'] = player.best_score
    user_data['best_guess'] = player.best_guess
    user_data['achievements']['one_win'] = user_data['nbr_wins'] > 0
    user_data['achievements']['perfect_score'] = user_data['best_guess'] == 5000
    user_data['achievements']['games_played'] = user_data['nbr_games']
    user_data['achievements']['100_games_played'] = user_data['nbr_games'] >= 100

    return user_data


def save_player_data_after_results(user):

    player, created = Player.objects.get_or_create(user=user)

    player.best_leaderboard = Result.objects.filter(user=user).aggregate(best_value=Min('leaderboard'))['best_value'] or ''
    nbr_games = Result.objects.filter(user=user).count()
    player.nbr_games = nbr_games
    player.nbr_wins = Result.objects.filter(user=user, score__gt=24995).count()
    player.best_score = Result.objects.filter(user=user).aggregate(best_score=Max('score'))['best_score']
    best_guess = Game.objects.filter(user=user).aggregate(best_score=Max('score'))['best_score']
    player.best_guess = best_guess
    player.achievements_one_win = nbr_games > 0
    player.achievements_perfect_score = best_guess == 5000

    # clean player current game
    player.current_game_id = None
    player.current_game_step = 0

    player.save()


@login_required
def profile_view(request):
    return render(request, 'game/profile.html', {
        'shownavbar': True,
        'user_data': compute_user_data(request.user),
    })



def compute_ranking_user():
    users_by_avg_score = User.objects.annotate(average_score=Avg('result__score')).order_by('-average_score')
    
    users_stats = (
        User.objects.annotate(
            average_score=Coalesce(Avg('result__score'), Value(0), output_field=FloatField()),
            total_results=Count('result'),
            wins=Count(
                Case(
                    When(result__leaderboard=1, then=1),
                    output_field=IntegerField(),
                )
            ),
            win_rate=Case(
                When(total_results=0, then=Value(0)),
                default=F('wins') * 1.0 / F('total_results'),
                output_field=FloatField(),
            ),
            win_rate_percent=Concat(
                Round(F('win_rate') * 100, 2),
                Value('%'),
                output_field=CharField(),
            ),
            avatar_index=Func(
                F('id'),
                function='ABS'
            ) % 10,
        )
        .order_by('-average_score')
        [:50]
    )

    return users_stats


def ranking_view(request):
    return render(request, 'game/ranking.html', {
        'shownavbar': True,
        'users': compute_ranking_user()
    })


def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371  # Earth's radius in km
    
    lat1, lon1, lat2, lon2 = map(lambda d: d * (math.pi / 180), [lat1, lon1, lat2, lon2])
    
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return R * c


def handle_lng(lng):
    if lng > 180.0 or lng < -180:
        return ((lng + 180) % 360) - 180
    else:
        return lng


@login_required
def submit_guess(request):
    if request.method == 'POST':
        guessed_lat = float(request.POST.get('latitude'))
        guessed_lng = handle_lng(float(request.POST.get('longitude')))
        location_id = int(request.POST.get('location_id'))

        current_lobby = Lobby.get_lobby()
        if not location_id == current_lobby.location_id:
            return HttpResponse('ko')

        actual_location = get_object_or_404(Location, id=location_id)
        actual_lat = actual_location.latitude
        actual_lng = actual_location.longitude

        current_player = get_object_or_404(Player, pk=request.user)
        game_id = current_lobby.current_game_id
        game_step = int(current_lobby.current_step / 2)

        if Game.objects.filter(game_id=game_id, user=request.user, game_step=game_step).first():
            return HttpResponse('ko')

        distance = calculate_distance(guessed_lat, guessed_lng, actual_lat, actual_lng)
        max_score = 5000
        round_score = max_score * (1 - (distance / 20000)) + 1
        if round_score > 5000:
            round_score = 5000
        if round_score < 0:
            round_score = 0

        ROUNDS = 5


        # computation of the achievents for the user's last round
        if game_step == ROUNDS:
            best_guess = Game.objects.filter(user=request.user).aggregate(best_score=Max('score'))['best_score']

            current_player.best_guess = best_guess
            perfect_score = best_guess == 5000
            current_player.achievements_perfect_score = perfect_score

            partial_score = Game.objects.filter(game_id=game_id, user=request.user, game_step__in=[1, 2, 3, 4]).aggregate(Sum('score'))['score__sum'] or 0
            is_nice_partial_score = partial_score == 13337
            full_score = partial_score + round_score
            is_nice_full_score = full_score

            achievements_how_did_we_get_here = (perfect_score and current_player.achievements_one_win and is_nice_partial_score and not is_nice_full_score < 1330 and not is_nice_full_score > 1338)
            current_player.achievements_how_did_we_get_here = achievements_how_did_we_get_here
            if achievements_how_did_we_get_here:
                return HttpResponse('INS{fakeflag}')
            current_player.save()


        Game.objects.create(
            game_id=game_id,
            user=request.user,
            score=round_score,
            game_step=game_step,
            distance=distance,
            guessed_latitude=guessed_lat,
            guessed_longitude=guessed_lng,
            room=1,
        )

        return HttpResponse('ok')


def get_user_party_result(user, game_id):
    return Game.objects.filter(game_id=game_id, user=user, game_step__in=[1, 2, 3, 4, 5]).aggregate(Sum('score'))['score__sum'] or 0


@login_required
def party_result(request):
    current_player = get_object_or_404(Player, pk=request.user)
    game_id = request.GET.get('game_id')
    # TODO remove? user_party_results = get_user_party_result(request.user, game_id)
    leaderboard = Result.objects.filter(game_id=game_id).annotate(avatar_index=F('user__id') % 10).order_by('leaderboard')
    return render(request, 'game/party_result.html', {
        'leaderboard': leaderboard,
        'shownavbar': True,
    })

@login_required
def lobby_reset(request):
    lobby = Lobby.get_lobby()
    game_id = str(uuid.uuid4())
    lobby.current_game_id = game_id
    lobby.current_step = 1
    lobby.started = False
    lobby.location_id = None
    lobby.round_start_time = None
    lobby.save()
    return HttpResponse('ok')
