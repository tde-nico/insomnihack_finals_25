# populate_data.py
import json
import os
from django.core.management.base import BaseCommand
from insoguessr.settings import BASE_DIR
from game.models import Location

class Command(BaseCommand):
    help = 'Populate Location data from JSON'

    def handle(self, *args, **kwargs):
        # Path to JSON
        dataset_file_path = os.path.join(BASE_DIR, 'dataset', 'prod_dataset', 'street_view_data.json')

        base_url = "/static/"

        # Open the JSON file and load its contents
        with open(dataset_file_path, 'r') as json_file:
            data = json.load(json_file)

        # Iterate over each item in the dataset
        for item in data:
            image_path = item.get('image_path')
            latitude = item.get('latitude')
            longitude = item.get('longitude')
            heading = item.get('heading')

            image_url = base_url + image_path + '.jpg'

            Location.objects.create(
                latitude=latitude,
                longitude=longitude,
                compass=heading,
                image_url=image_url
            )

        self.stdout.write(self.style.SUCCESS(f'Successfully populated {len(data)} records'))

