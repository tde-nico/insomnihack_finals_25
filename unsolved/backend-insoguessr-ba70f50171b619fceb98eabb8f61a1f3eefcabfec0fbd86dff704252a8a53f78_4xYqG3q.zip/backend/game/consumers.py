import json
from datetime import datetime
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async
from django.shortcuts import get_object_or_404
from channels.layers import get_channel_layer
from .models import Lobby, User

# Calculate final results
from .models import Game, Result
from django.db.models import Sum
from .views import save_player_data_after_results

import json
import asyncio
import random
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
import uuid
from .models import Lobby, Player, Location

from django.core.cache import cache

TASK_LOCK_KEY = "TASK"
COUNTDOWN_DURATION = 5
ROUND_DURATION = 30
NUMBER_OF_ROUNDS = 5
INTERMEDIARY_ROUND_DURATION = 15
ENDGAME_DURATION = 3
VERBOSE = True

class RealLobbyConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        self.LOBBY_GROUP_NAME = "game_lobby"
        await self.channel_layer.group_add(self.LOBBY_GROUP_NAME, self.channel_name)

        if self.scope["user"].is_authenticated:
            await self.accept()

            task_running = cache.get(TASK_LOCK_KEY)


            if not (task_running is not None and task_running['running']):
                asyncio.create_task(self.start_game_lobby())
            
            #if not (task_running is not None and task_running['started']):
            lobby_update = await self.add_user_to_lobby(self.scope["user"])

            await self.send(text_data=json.dumps({
                'type': 'lobby_status_update',
                'current_step': lobby_update['current_step'],
                'game_id': lobby_update['game_id'],
                'started': lobby_update['started'],
                'next_step_time': lobby_update['next_step_time'],
                'player_count': lobby_update['player_count'],
                'sleep_time': lobby_update['sleep_time'],
            }))

    async def disconnect(self, close_code):
        # Remove user from the lobby when they disconnect
        if self.scope["user"].is_authenticated:
            lobby_update = await self.remove_user_from_lobby(self.scope["user"])

            await self.send(text_data=json.dumps({
                'type': 'lobby_status_update',
                'current_step': lobby_update['current_step'],
                'game_id': lobby_update['game_id'],
                'started': lobby_update['started'],
                'next_step_time': lobby_update['next_step_time'],
                'player_count': lobby_update['player_count'],
                'sleep_time': lobby_update['sleep_time'],
            }))

        await self.channel_layer.group_discard(
            self.LOBBY_GROUP_NAME,
            self.channel_name
        )

    async def lobby_status_update(self, event):
        await self.send(text_data=json.dumps({
            'type': 'lobby_status_update',
            'current_step': event['current_step'],
            'game_id': event['game_id'],
            'started': event['started'],
            'player_count': event['player_count'],
            'next_step_time': event['next_step_time'],
            'sleep_time': event['sleep_time'],
            'round_leaderboard': event['round_leaderboard'] if 'round_leaderboard' in event else None,
        }))

    async def start_game_lobby(self):
        if VERBOSE: print("start game lobby triggered")
        task_running = cache.get(TASK_LOCK_KEY)
        if (task_running is not None and task_running['running']):
            if VERBOSE: print("background task already running", task_running)
            return

        if VERBOSE: print("game lobby starting")

        # initial lobby values
        next_step_time = timezone.now()
        game_id = str(uuid.uuid4())
        current_step = 1
        started = False
        running = True
        location_id = await self.compute_location_id()

        # waiting room
        current_step, next_step_time = await self.handle_one_step(current_step, game_id, started, running, next_step_time, COUNTDOWN_DURATION, location_id)

        started = True
        # game begins
        for round_nbr in range(1, NUMBER_OF_ROUNDS+1):
            location_id = await self.compute_location_id()
            if VERBOSE: print(f"game {round_nbr} starting! Location ID: {location_id}")
            current_step, next_step_time = await self.handle_one_step(current_step, game_id, started, running, next_step_time, ROUND_DURATION, location_id)
            if VERBOSE: print(f"game {round_nbr} ended")
            #if round_nbr != NUMBER_OF_ROUNDS:
            if VERBOSE: print("Intermediary lobby time started")
            current_step, next_step_time = await self.handle_one_step(current_step, game_id, started, running, next_step_time, INTERMEDIARY_ROUND_DURATION, location_id)
            if VERBOSE: print("End of the intermediary lobby")
            if VERBOSE: print()
        await self.end_game()
        if VERBOSE: print("end of the game, leaderboard displayed")
        current_step, next_step_time = await self.handle_one_step(current_step, game_id, started, running, next_step_time, ENDGAME_DURATION, location_id)
        await self.set_lobby_data(current_step=0, game_id=None, started=False, next_step_time=None, sleep_time=None, location_id=location_id)
        await self.clean_players()


    async def handle_one_step(self, current_step, game_id, started, running, next_step_time, sleep_time, location_id):
        next_step_time = next_step_time + timedelta(seconds=sleep_time)
        task = {
            'started': started,
            'running': running,
            'step': current_step,
            'game_id': game_id,
            'next_step_time': next_step_time,
            'sleep_time': sleep_time,
        }
        cache.set(TASK_LOCK_KEY, task, timeout=sleep_time+5)
        lobby_update = await self.set_lobby_data(current_step=current_step, game_id=game_id, started=started, next_step_time=next_step_time, sleep_time=sleep_time, location_id=location_id)
        round_leaderboard = None
        if current_step % 2 == 0 and current_step > 1:
            current_game_step = int(current_step / 2)
            await self.add_bot_result(current_game_step=current_game_step, game_id=game_id)
        if current_step % 2 == 1 and current_step > 0:
            current_game_step = int(current_step / 2)
            round_leaderboard = await self.compute_round_leaderboard(current_game_step=current_game_step, game_id=game_id)
        # broadcast info        
        await self.channel_layer.group_send(
            self.LOBBY_GROUP_NAME,
            {
                'type': 'lobby_status_update',
                'current_step': lobby_update['current_step'],
                'game_id': lobby_update['game_id'],
                'started': lobby_update['started'],
                'next_step_time': lobby_update['next_step_time'],
                'player_count': lobby_update['player_count'],
                'sleep_time': lobby_update['sleep_time'],
                'round_leaderboard': round_leaderboard,
            }
        )
        if VERBOSE: print('current step:', current_step, 'game_id:', game_id, 'next_step_time:', next_step_time, 'sleeping delay:', sleep_time)
        await asyncio.sleep(sleep_time)

        return current_step + 1, next_step_time

    @database_sync_to_async
    def compute_location_id(self):
        location_id = Lobby.get_lobby().location_id
        if not location_id:
            location_id = Location.objects.all().only('id').first().id
        else:
            location_id = Location.objects.filter(id__gt=location_id).only('id').first().id

            if not location_id:
                location_id = Location.object.all().only('id').first().id
        return location_id

    @database_sync_to_async
    def add_bot_result(self, current_game_step, game_id):

        bot_user = get_object_or_404(User, username='bot')
        current_lobby = Lobby.get_lobby()
        location_id = current_lobby.location_id

        actual_location = get_object_or_404(Location, id=location_id)
        actual_lat = actual_location.latitude
        actual_lng = actual_location.longitude

        Game.objects.create(
            game_id=game_id,
            user=bot_user,
            score=4999,
            game_step=current_game_step,
            distance=1,
            guessed_latitude=actual_lat,
            guessed_longitude=actual_lng + 0.07,
            room=1,
        )


    @database_sync_to_async
    def compute_round_leaderboard(self, current_game_step, game_id):
        bot_user = get_object_or_404(User, username='bot')
        games = Game.objects.filter(game_id=game_id, game_step=current_game_step).select_related('user').order_by('-score')
        top_ten_games = list(games[:10])
        bot_game = games.filter(user=bot_user).first()
        if bot_game and bot_game not in top_ten_games:
            top_ten_games.append(bot_game)
        leaderboard = [
            {
                "user": game.user.username,
                "latitude": game.guessed_latitude,
                "longitude": game.guessed_longitude,
                "score": game.score,
                "user_id": game.user.id,
            }
            for game in games
        ]
        return leaderboard


    @database_sync_to_async
    def end_game(self):
        lobby = Lobby.get_lobby()
        game_id = lobby.current_game_id
        player_scores = Game.objects.filter(
            game_id=game_id,
            game_step__in=[1, 2, 3, 4, 5]
        ).values('user').annotate(
            total_score=Sum('score')
        ).order_by('-total_score')
        print(player_scores)
        # Assign leaderboard positions
        position = 1
        for player_score in player_scores:
            Result.objects.create(
                game_id=game_id,
                user_id=player_score['user'],
                room=1,
                score=player_score['total_score'],
                leaderboard=position
            )
            position += 1
        
        # Update player statistics
        for user in lobby.players.all():
            save_player_data_after_results(user)
            
            # Reset player game state
            player = Player.objects.get(user=user)
            player.current_game_id = None
            player.current_game_step = 0
            player.save()
        
        return list(player_scores)


    async def receive(self, text_data):
        pass


    @database_sync_to_async
    def set_lobby_data(self, current_step, game_id, started, next_step_time, sleep_time, location_id):
        lobby = Lobby.get_lobby()
        
        lobby.current_step = current_step
        lobby.current_game_id = game_id
        lobby.started = started
        lobby.round_start_time = next_step_time
        lobby.sleep_time = sleep_time
        lobby.location_id = location_id
        lobby.save()    

        # Get updated player list
        players = list(lobby.players.values_list('username', flat=True))

        next_step_time = None
        if lobby.round_start_time:
            next_step_time = lobby.round_start_time.isoformat()

        return {
            'current_step': lobby.current_step,
            'game_id': lobby.current_game_id,
            'started': lobby.started,
            'next_step_time': next_step_time,
            'player_count': len(players),
            'sleep_time': lobby.sleep_time,
            'location_id': lobby.location_id,
        }

    @database_sync_to_async
    def add_user_to_lobby(self, user):
        lobby = Lobby.get_lobby()
        lobby.players.add(user)
        
        # Reset player's game data
        player, _ = Player.objects.get_or_create(user=user)
        if lobby.current_game_id:
            player.current_game_id = lobby.current_game_id
            player.current_game_step = lobby.current_step
        player.save()
        
        # Get updated player list
        players = list(lobby.players.values_list('username', flat=True))
        
        next_step_time = None
        if lobby.round_start_time:
            next_step_time = lobby.round_start_time.isoformat()

        # Broadcast lobby status to all connected clients
        return {
            'current_step': lobby.current_step,
            'game_id': lobby.current_game_id,
            'started': lobby.started,
            'next_step_time': next_step_time,
            'player_count': len(players),
            'sleep_time': lobby.sleep_time,
            'location_id': lobby.location_id,
        }


    @database_sync_to_async
    def remove_user_from_lobby(self, user):
        lobby = Lobby.get_lobby()
        lobby.players.remove(user)
        
        # Get updated player list
        players = list(lobby.players.values_list('username', flat=True))
        
        next_step_time = None
        if lobby.round_start_time:
            next_step_time = lobby.round_start_time.isoformat()

        # Broadcast lobby status to all connected clients
        return {
            'current_step': lobby.current_step,
            'game_id': lobby.current_game_id,
            'started': lobby.started,
            'next_step_time': next_step_time,
            'player_count': len(players),
            'sleep_time': lobby.sleep_time,
            'location_id': lobby.location_id,
        }

    @database_sync_to_async
    def clean_players(self):
        lobby.players.clear()
