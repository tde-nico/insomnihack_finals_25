from django.contrib import admin
from .models import Location, Game, Result, Player, Lobby

class LocationAdmin(admin.ModelAdmin):
    list_display = ('latitude', 'longitude', 'compass', 'image_url')
    search_fields = ('latitude', 'longitude', 'compass', 'image_url')
    list_filter = ('latitude', 'longitude', 'compass', 'image_url')

admin.site.register(Location, LocationAdmin)

class GameAdmin(admin.ModelAdmin):
    list_display = ('game_id', 'game_step', 'user', 'score', 'distance', 'room', 'date_played')
    search_fields = ('game_id', 'game_step', 'user', 'score', 'distance', 'room', 'date_played')
    list_filter = ('game_id', 'game_step', 'user', 'score', 'distance', 'room', 'date_played')

admin.site.register(Game, GameAdmin)

class ResultAdmin(admin.ModelAdmin):
    list_display = ('game_id', 'user', 'room', 'score', 'leaderboard', 'date_played')
    search_fields = ('game_id', 'user', 'room', 'score', 'leaderboard', 'date_played')
    list_filter = ('game_id', 'user', 'room', 'score', 'leaderboard', 'date_played')

admin.site.register(Result, ResultAdmin)

class PlayerAdmin(admin.ModelAdmin):
    list_display = ('user', 'best_guess', 'best_score', 'best_leaderboard', 'nbr_games', 'nbr_wins', 'achievements_one_win', 'achievements_perfect_score', 'current_game_id', 'current_game_step')
    search_fields = ('user', 'best_guess', 'best_score', 'best_leaderboard', 'nbr_games', 'nbr_wins', 'achievements_one_win', 'achievements_perfect_score', 'current_game_id', 'current_game_step')
    list_filter = ('user', 'best_guess', 'best_score', 'best_leaderboard', 'nbr_games', 'nbr_wins', 'achievements_one_win', 'achievements_perfect_score', 'current_game_id', 'current_game_step')

admin.site.register(Player, PlayerAdmin)

class LobbyAdmin(admin.ModelAdmin):
    list_display = ('started', 'current_game_id', 'current_step', 'round_start_time',)
admin.site.register(Lobby, LobbyAdmin)
