from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path
from django.shortcuts import redirect

urlpatterns = [
    path('', include('game.urls')),
    path('admin/', admin.site.urls),
]
